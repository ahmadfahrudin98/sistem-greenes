<?php 
include "config/koneksi.php";
include "config/fungsi_indotgl.php";
include "config/class_paging.php";
include "config/library.php"; 
include "config/fungsi_thumbuser.php";
include "page/index.php"; 
?>
