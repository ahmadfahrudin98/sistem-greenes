<html>
<head>
	<title>Input soal</title>
</head>
<body>
 



<form action="input_soal.php" method="get">
	<label for="soal">Soal</label>
	<input type="text" name="soal" id="soal"></input>
	<button type="submit">Masukan Soal</button>
		

	</form>





</body>
</html>

<?php

	$server = "localhost";
	$user = "root";
	$password = "";
	$db_name = "green";

	$db = mysqli_connect($server, $user, $password, $db_name);
	if(!$db){

		die("gagal".mysqli_connect_error());
	}

	$soal = $_GET['soal'];
	var_dump($soal);
	$query = "INSERT INTO soal VALUE ('','$soal')";
	mysqli_query($db, $query);
?>